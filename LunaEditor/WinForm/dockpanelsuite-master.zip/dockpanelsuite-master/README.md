dockpanelsuite
==============

[![Join the chat at https://gitter.im/dockpanelsuite/dockpanelsuite](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/dockpanelsuite/dockpanelsuite?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

DockPanel Suite - The Visual Studio inspired docking library for .NET WinForms

For all the details, check out [http://dockpanelsuite.com](http://dockpanelsuite.com).
